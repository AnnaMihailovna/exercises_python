# 87722589
from typing import List, Optional


class Deque:
    """Класс двухсторонней очереди."""
    def __init__(self, max_length: int) -> None:
        self.deque: List[Optional[int]] = [None] * max_length
        self.max_length: int = max_length
        self.head: int = 0
        self.tail: int = 0
        self.size: int = 0
    
    def is_empty(self) -> bool:
        """Возвращает True, если очередь пустая."""
        return self.size == 0
    
    def push_back(self, value: int) -> None:
        """Добавляет элемент в конец очереди."""
        if self.size != self.max_length:
            self.deque[self.tail] = value
            self.tail = (self.tail + 1)%self.max_length
            self.size += 1
        else:
            return 'error'
    
    def push_front(self, value: int) -> None:
        """Добавляет элемент в начало очереди."""
        if self.size != self.max_length:
            self.deque[self.head - 1] = value
            self.head = (self.head - 1)%self.max_length
            self.size += 1
        else:
            return 'error'
    
    def pop_front(self) -> int:
        """Удаляет крайний элемент с головы очереди
        и возвращает его.
        """
        if self.is_empty():
            return 'error'
        value = self.deque[self.head]
        self.deque[self.head] = None
        self.head = (self.head + 1)%self.max_length
        self.size -= 1
        return value
    
    def pop_back(self) -> int:
        """Удаляет крайний элемент с хвоста очереди
        и возвращает его.
        """
        if self.is_empty():
            return 'error'
        value = self.deque[self.tail - 1]
        self.deque[self.tail - 1] = None
        self.tail = (self.tail - 1)%self.max_length
        self.size -= 1
        return value


def main():
    """Основная логика программы."""
    n = int(input())
    max_length = int(input())
    deque = Deque(max_length)
    result = []
    for command in range(n):
        command = input().split()
        if command[0] == 'push_back':
            a = deque.push_back(command[1])
            if a == 'error':
                result.append(a)
        elif command[0] == 'push_front':
            a = deque.push_front(command[1])
            if a == 'error':
                result.append(a)
        elif command[0] == 'pop_front':
            result.append(deque.pop_front())
        elif command[0] == 'pop_back':
            result.append(deque.pop_back())
    for i in result:
        print(i)

if __name__ == '__main__':
    main()
